"""Prompt management module."""

"""Context management module."""

"""Data ingestion module."""

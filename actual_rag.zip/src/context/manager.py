from __future__ import annotations

from pathlib import Path
from typing import TypedDict

from src.config.settings import BASE_VECTOR_PATH
from src.context.selector import match_namespace
from src.ingest.core import (
    ChunkMetadata,
    CollectionPaths,
    RawCollection,
    load_collection,
)
from src.utils.logger import logger

if False:  # TYPE_CHECKING — evita import circular en runtime
    from faiss import Index as FaissIndex
    import numpy as np


# ======================================================
# TIPOS
# ======================================================


class LoadedCollection(TypedDict):
    """
    Colección completamente cargada en memoria.
    Extiende RawCollection con el nombre lógico asignado por ContextManager.
    """

    index: FaissIndex | None  # type: ignore[type-arg]
    metadata: list[ChunkMetadata]
    vectors: np.ndarray | None  # type: ignore[name-defined]
    paths: CollectionPaths
    collection_name: str


# ======================================================
# MANAGER
# ======================================================


class ContextManager:

    def __init__(self) -> None:
        self.base_path: Path = Path(BASE_VECTOR_PATH)
        self.loaded_contexts: dict[str, LoadedCollection] = {}

    # =====================================================
    # DISCOVERY
    # =====================================================

    def list_all(self) -> list[str]:
        """
        Recorre base_path y devuelve todas las colecciones disponibles
        en disco con el formato 'namespace/coleccion', ordenadas
        alfabéticamente.
        """
        contexts: list[str] = []

        if not self.base_path.exists():
            return contexts

        for namespace in self.base_path.iterdir():
            if not namespace.is_dir():
                continue

            for collection in namespace.iterdir():
                if collection.is_dir():
                    contexts.append(f"{namespace.name}/{collection.name}")

        return sorted(contexts)

    # =====================================================
    # RESOLUTION
    # =====================================================

    def resolve_pattern(self, pattern: str) -> list[str]:
        """
        Resuelve un patrón (namespace o colección exacta) contra
        las colecciones disponibles en disco.
        """
        available: list[str] = self.list_all()

        return match_namespace(
            pattern=pattern,
            available_contexts=available,
        )

    # =====================================================
    # ACTIVATION
    # =====================================================

    def activate(self, pattern: str) -> list[str]:
        """
        Carga en memoria las colecciones que coinciden con el patrón.
        Las ya cargadas se omiten sin error.

        Retorna los nombres de las colecciones efectivamente cargadas.
        """
        matches: list[str] = self.resolve_pattern(pattern)

        if not matches:
            return []

        loaded: list[str] = []

        for context_name in matches:
            if context_name in self.loaded_contexts:
                continue

            try:
                raw: RawCollection = load_collection(context_name)

                self.loaded_contexts[context_name] = LoadedCollection(
                    index=raw["index"],
                    metadata=raw["metadata"],
                    vectors=raw["vectors"],
                    paths=raw["paths"],
                    collection_name=context_name,
                )

                loaded.append(context_name)
                logger.info(f"Contexto cargado: {context_name}")

            except Exception:
                logger.exception(f"Error cargando contexto: {context_name}")

        return loaded

    # =====================================================
    # DEACTIVATION
    # =====================================================

    def deactivate(self, pattern: str) -> list[str]:
        """
        Descarga de memoria las colecciones que coinciden con el patrón.
        Las que no están activas se omiten sin error.

        Retorna los nombres de las colecciones descargadas.
        """
        matches: list[str] = self.resolve_pattern(pattern)
        removed: list[str] = []

        for context_name in matches:
            if context_name in self.loaded_contexts:
                del self.loaded_contexts[context_name]
                removed.append(context_name)
                logger.info(f"Contexto descargado: {context_name}")

        return removed

    def clear(self) -> None:
        """Descarga todos los contextos activos."""
        self.loaded_contexts.clear()
        logger.info("Todos los contextos fueron descargados")

    # =====================================================
    # GETTERS
    # =====================================================

    def get_active(self) -> list[str]:
        """Devuelve los nombres de los contextos activos."""
        return list(self.loaded_contexts.keys())

    def get_loaded_collections(self) -> list[LoadedCollection]:
        """Devuelve las colecciones cargadas en memoria."""
        return list(self.loaded_contexts.values())

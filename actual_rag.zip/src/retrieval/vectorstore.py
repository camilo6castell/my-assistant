import numpy as np


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.dot(a, b))


def normalize_embedding(embedding: np.ndarray | list[float]) -> np.ndarray:
    arr = np.array(embedding, dtype="float32")
    norm = np.linalg.norm(arr)

    if norm == 0.0:
        return arr

    return arr / norm
